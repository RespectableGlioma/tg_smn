from .common import Game, StepOutput
from .othello import Othello
from .game2048 import Game2048
